# Installment Car System

Sistem manajemen cicilan mobil berbasis Web menggunakan:
- Laravel (REST API + Sanctum)
- React.js (Frontend + PWA)
- Postman (API Documentation)

## Features
- Authentication (Admin & User)
- Role-based Access Control
- Installment Car Management
- Society & Application Management
- Validation Workflow

## Tech Stack
- Backend: Laravel 10, Sanctum
- Frontend: React.js, React Router, Axios
- Database: MySQL
- API Tool: Postman

## Installation

### Backend
```bash
cd backend
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
php artisan serve

### Frontend
```bash
cd frontend
npm install
npm run dev