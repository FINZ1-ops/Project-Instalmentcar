<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\InstalmentCarController;
use App\Http\Controllers\ApplicationController;
use App\Http\Controllers\SocietyController;
use App\Http\Controllers\ValidationController;

Route::post('/register', [AuthController::class, 'register']);

Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');
Route::middleware(['auth:sanctum', 'role:user'])->group(function () {
    Route::post('/validation', [ValidationController::class, 'store']);

    Route::post('/application', [ApplicationController::class, 'store']);

    Route::get('/user/instalment-car', [InstalmentCarController::class, 'index']);
    
    Route::get('/society/{id}', [SocietyController::class, 'show']);
    Route::post('/society', [SocietyController::class, 'store']);
    Route::put('/society/{id}', [SocietyController::class, 'update']);
});

Route::middleware(['auth:sanctum', 'role:admin'])->group(function () {
    Route::get('/instalment-car', [InstalmentCarController::class, 'index']);
    Route::get('/instalment-car/{id}', [InstalmentCarController::class, 'show']);
    Route::post('/instalment-car', [InstalmentCarController::class, 'store']);
    Route::put('/instalment-car/{id}', [InstalmentCarController::class, 'update']);
    Route::delete('/instalment-car/{id}', [InstalmentCarController::class, 'destroy']);

    Route::get('/validation', [ValidationController::class, 'index']);
    Route::put('/validation/{id}/approve', [ValidationController::class, 'approve']);
    Route::put('/validation/{id}/reject', [ValidationController::class, 'reject']);

    Route::get('/application', [ApplicationController::class, 'index']);

    Route::get('/society', [SocietyController::class, 'index']);
    Route::get('/society/{id}', [SocietyController::class, 'show']);
    Route::delete('/society/{id}', [SocietyController::class, 'destroy']);
});
