<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\Application;

class Society extends Model
{
    protected $fillable = [
        'user_id',
        'id_card_number',
        'name',
        'address',
        'phone'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function validation()
    {
        return $this->hasOne(Validation::class);
    }

    public function application()
    {
        return $this->hasOne(Application::class);
    }

}
