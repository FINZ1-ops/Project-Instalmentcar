<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Validation extends Model
{
    protected $fillable = [
        'society_id',
        'job',
        'income',
        'reason_accepted',
        'status',
        'validator_id'
    ];

    public function society()
    {
        return $this->belongsTo(Society::class);
    }

        public function application()
    {
        return $this->belongsTo(Application::class);
    }

}
