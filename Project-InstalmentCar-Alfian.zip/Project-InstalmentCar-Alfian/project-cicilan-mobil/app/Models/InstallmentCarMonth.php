<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InstallmentCarMonth extends Model
{
    protected $fillable = [
        'instalment_car_id',
        'month'
    ];

    public function car()
    {
        return $this->belongsTo(InstalmentCar::class);
    }
}

