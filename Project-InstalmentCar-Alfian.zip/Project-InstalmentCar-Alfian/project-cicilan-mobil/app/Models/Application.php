<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Application extends Model
{
    protected $fillable = [
        'society_id',
        'instalment_car_id',
        'instalment_car_month_id',
        'monthly_payment',
        'status'
    ];

        public function society()
    {
        return $this->belongsTo(Society::class);
    }

    public function validation()
    {
        return $this->hasOne(Validation::class);
    }

    public function car()
    {
        return $this->belongsTo(InstalmentCar::class);
    }

    public function month()
    {
        return $this->belongsTo(InstalmentCarMonth::class);
    }
}

