<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\InstallmentCarMonth;

class InstalmentCar extends Model
{
    protected $table = 'instalment_cars'; 

    protected $fillable = [
        'brand',
        'model',
        'price'
    ];

    public function months()
    {
        return $this->hasMany(InstallmentCarMonth::class);
    }
}

