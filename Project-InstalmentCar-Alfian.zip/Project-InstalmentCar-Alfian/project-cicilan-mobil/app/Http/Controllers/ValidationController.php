<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Validation;

class ValidationController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'job' => 'required',
            'income' => 'required|integer'
        ]);

        if (Validation::where('society_id', $request->society_id)->exists()) {
            return response()->json([
                'message' => 'Validation already submitted'
            ], 400);
        }

        Validation::create([
            'society_id' => $request->society_id,
            'job' => $request->job,
            'income' => $request->income
        ]);

        return response()->json(['message' => 'Validation submitted']);
    }

    public function index()
    {
        $validations = Validation::with('society')->get();

        return response()->json([
            'data' => $validations
        ]);
    }

    public function approve($id)
    {
        $validation = Validation::findOrFail($id);
        $validation->update([
            'status' => 'accepted'
        ]);

        return response()->json(['message' => 'Validation approved']);
    }

    public function reject(Request $request, $id)
    {
        $validation = Validation::findOrFail($id);
        $validation->update([
            'status' => 'rejected',
            'reason_accepted' => $request->reason
        ]);

        return response()->json(['message' => 'Validation rejected']);
    }


}
