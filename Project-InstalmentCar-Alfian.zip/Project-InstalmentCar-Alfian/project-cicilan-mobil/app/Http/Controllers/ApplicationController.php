<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Application;
use App\Models\Validation;
use App\Models\InstalmentCar;
use App\Models\InstallmentCarMonth;

class ApplicationController extends Controller
{
    public function index()
    {
        $applications = Application::with(['society', 'instalmentCar', 'instalmentCarMonth'])->get();

        return response()->json([
            'data' => $applications
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'society_id' => 'required',
            'instalment_car_id' => 'required',
            'instalment_car_month_id' => 'required'
        ]);

        $validation = Validation::where('society_id', $request->society_id)
            ->where('status', 'accepted')
            ->first();

        if (!$validation) {
            return response()->json([
                'message' => 'Society not validated'
            ], 403);
        }

        if (Application::where('society_id', $request->society_id)->exists()) {
            return response()->json([
                'message' => 'Application already exists'
            ], 400);
        }

        $car = InstalmentCar::findOrFail($request->instalment_car_id);
        $month = InstallmentCarMonth::findOrFail($request->instalment_car_month_id);

        $monthlyPayment = $car->price / $month->month;

        Application::create([
            'society_id' => $request->society_id,
            'instalment_car_id' => $car->id,
            'instalment_car_month_id' => $month->id,
            'monthly_payment' => $monthlyPayment
        ]);

        return response()->json(['message' => 'Application submitted']);
    }

}
