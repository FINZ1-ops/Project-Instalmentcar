<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Society;

class SocietyController extends Controller
{

    public function index()
    {
        return response()->json([
            'data' => Society::with('user')->get()
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_card_number' => 'required|unique:societies',
            'name' => 'required',
            'address' => 'required',
            'phone' => 'required'
        ]);

        $society = Society::create([
            'user_id' => $request->user()->id,
            'id_card_number' => $request->id_card_number,
            'name' => $request->name,
            'address' => $request->address,
            'phone' => $request->phone,
        ]);

        return response()->json([
            'message' => 'Society created',
            'data' => $society
        ], 201);
    }

    public function show($id)
    {
        $society = Society::with(['validation', 'application'])->findOrFail($id);

        return response()->json([
            'data' => $society
        ]);
    }

    public function update(Request $request, $id)
    {
        $society = Society::findOrFail($id);

        $request->validate([
            'name' => 'sometimes|required',
            'address' => 'sometimes|required',
            'phone' => 'sometimes|required',
        ]);

        $society->update($request->only([
            'name',
            'address',
            'phone'
        ]));

        return response()->json([
            'message' => 'Society updated',
            'data' => $society
        ]);
    }

    public function destroy($id)
    {
        Society::findOrFail($id)->delete();

        return response()->json([
            'message' => 'Society deleted'
        ]);
    }
}
