<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\InstalmentCar;

class InstalmentCarController extends Controller
{
    public function index()
    {
        return InstalmentCar::with('months')->get();
    }

    public function store(Request $request)
    {
        $request->validate([
            'brand' => 'required',
            'model' => 'required',
            'price' => 'required|integer'
        ]);

        $car = InstalmentCar::create([
            'brand' => $request->brand,
            'model' => $request->model,
            'price' => $request->price
        ]);

        return response()->json([
            'message' => 'Car created',
            'data' => $car
        ]);
    }

    public function update(Request $request, $id)
    {
        $car = InstalmentCar::findOrFail($id);

        $request->validate([
            'brand' => 'sometimes|required',
            'model' => 'sometimes|required',
            'price' => 'sometimes|required|integer'
        ]);

        $car->update($request->only(['brand', 'model', 'price']));

        return response()->json([
            'message' => 'Car updated',
            'data' => $car
        ]);
    }

    public function show($id)
    {
        return InstalmentCar::with('months')->findOrFail($id);
    }

    public function destroy($id)
    {
        $car = InstalmentCar::findOrFail($id);
        $car->delete();

        return response()->json(['message' => 'Car deleted']);
    }
}

