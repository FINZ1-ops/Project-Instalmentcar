import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

// auth
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";

import AdminRoute from "./routes/AdminRoute";
import UserRoute from "./routes/UserRoute";

// layouts
import AdminLayout from "./layouts/AdminLayout";
import UserLayout from "./layouts/UserLayout";


// admin pages
import AdminDashboard from "./pages/admin/Dashboard";
import AdminApplication from "./pages/admin/Application";
import AdminSociety from "./pages/admin/Society";
import AdminInstallmentCar from "./pages/admin/InstallmentCar";
import AdminValidation from "./pages/admin/Validation";

// user pages
import UserDashboard from "./pages/user/Dashboard";
import UserApplication from "./pages/user/Application";
import UserSociety from "./pages/user/Society";
import UserInstallmentCar from "./pages/user/InstalmentCar";
import UserValidation from "./pages/user/Validation";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
         <Route path="/" element={<Navigate to="/register"/>}/>

        {/* AUTH */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* ADMIN */}
        <Route element={<AdminRoute />}>
          <Route element={<AdminLayout />}>
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/admin/application" element={<AdminApplication />} />
            <Route path="/admin/society" element={<AdminSociety />} />
            <Route path="/admin/installment-car" element={<AdminInstallmentCar />} />
            <Route path="/admin/validation" element={<AdminValidation />} />
          </Route>
        </Route>

        {/* USER */}
        <Route element={<UserRoute />}>
          <Route element={<UserLayout />}>
            <Route path="/user/dashboard" element={<UserDashboard />} />
            <Route path="/user/application" element={<UserApplication />} />
            <Route path="/user/society" element={<UserSociety />} />
            <Route path="/user/installment-car" element={<UserInstallmentCar />} />
            <Route path="/user/validation" element={<UserValidation />} />
          </Route>
        </Route>

        {/* fallback */}
        <Route path="*" element={<Login />} />

      </Routes>
    </BrowserRouter>
  );
}
