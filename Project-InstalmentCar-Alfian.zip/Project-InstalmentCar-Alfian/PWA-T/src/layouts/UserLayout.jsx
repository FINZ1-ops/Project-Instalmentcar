import { Link, Outlet, useNavigate } from "react-router-dom";
import "../pages/user/User.css";

export default function UserLayout() {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <div className="user-wrapper d-flex">
      {/* Sidebar */}
      <aside className="sidebar p-3">
        <h5 className="brand mb-4">Cicilan Mobil</h5>

        <ul className="nav flex-column gap-2">
          <li><Link to="/user/dashboard">Dashboard</Link></li>
          <li><Link to="/user/instalment-car">Mobil</Link></li>
          <li><Link to="/user/validation">Validasi</Link></li>
          <li><Link to="/user/application">Pengajuan</Link></li>
          <li><Link to="/user/society">Profil</Link></li>
          <li>
            <button onClick={logout} className="btn btn-sm btn-danger w-100 mt-3">
              Logout
            </button>
          </li>
        </ul>
      </aside>

      {/* Content */}
      <main className="content flex-fill p-4">
        <Outlet />
      </main>
    </div>
  );
}
