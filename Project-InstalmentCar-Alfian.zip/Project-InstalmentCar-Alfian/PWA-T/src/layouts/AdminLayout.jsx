import { Outlet, useNavigate } from "react-router-dom";
import "../pages/admin/Admin.css"

export default function AdminLayout() {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <div className="d-flex" style={{ minHeight: "100vh" }}>
      {/* Sidebar */}
      <div className="bg-dark text-white p-3" style={{ width: 240 }}>
        <h5 className="mb-4">Admin Panel</h5>
        <ul className="nav flex-column gap-2">
          <li><button className="btn btn-dark w-100 text-start" onClick={() => navigate("/admin/dashboard")}>Dashboard</button></li>
          <li><button className="btn btn-dark w-100 text-start" onClick={() => navigate("/admin/installment-car")}>Instalment Car</button></li>
          <li><button className="btn btn-dark w-100 text-start" onClick={() => navigate("/admin/validation")}>Validation</button></li>
          <li><button className="btn btn-dark w-100 text-start" onClick={() => navigate("/admin/application")}>Application</button></li>
          <li><button className="btn btn-dark w-100 text-start" onClick={() => navigate("/admin/society")}>Society</button></li>
        </ul>
      </div>

      {/* Content */}
      <div className="flex-fill">
        <nav className="navbar bg-light px-4 shadow-sm">
          <span className="navbar-brand">Dashboard</span>
          <button className="btn btn-outline-danger btn-sm" onClick={logout}>Logout</button>
        </nav>

        <main className="p-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
