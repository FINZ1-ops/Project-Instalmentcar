export default function Dashboard() {
  return (
    <>
      <h4 className="mb-4">Dashboard User</h4>

      <div className="row g-4">
        <div className="col-md-4">
          <div className="card stat-card">
            <div className="card-body">
              <p>Status Validasi</p>
              <h5>Menunggu</h5>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card stat-card">
            <div className="card-body">
              <p>Pengajuan</p>
              <h5>Belum Ada</h5>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card stat-card">
            <div className="card-body">
              <p>Mobil Tersedia</p>
              <h5>Daftar Mobil</h5>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
