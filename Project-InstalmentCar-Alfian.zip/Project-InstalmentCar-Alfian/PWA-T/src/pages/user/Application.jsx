import { useEffect, useState } from "react";
import api from "../../services/api";

export default function Application() {
  const [cars, setCars] = useState([]);
  const [form, setForm] = useState({ instalment_car_id: "", instalment_car_month_id: "" });

  useEffect(() => {
    api.get("/instalment-car").then(res => setCars(res.data));
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    await api.post("/application", form);
    alert("Pengajuan berhasil");
  };

  return (
    <>
      <h4>Ajukan Cicilan</h4>

      <form onSubmit={submit} className="card p-3 mt-3" style={{ maxWidth: 400 }}>
        <select className="form-control mb-2"
          onChange={(e) => setForm({ ...form, instalment_car_id: e.target.value })}>
          <option value="">Pilih Mobil</option>
          {cars.map(c => (
            <option key={c.id} value={c.id}>{c.brand} {c.model}</option>
          ))}
        </select>

        <input
          className="form-control mb-3"
          placeholder="ID Bulan Cicilan"
          onChange={(e) => setForm({ ...form, instalment_car_month_id: e.target.value })}
        />

        <button className="btn btn-success">Submit</button>
      </form>
    </>
  );
}
