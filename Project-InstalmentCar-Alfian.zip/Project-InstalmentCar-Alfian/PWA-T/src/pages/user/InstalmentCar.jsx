import { useEffect, useState } from "react";
import api from "../../services/api";

export default function InstallmentCar() {
  const [cars, setCars] = useState([]);

  useEffect(() => {
    api.get("/user/instalment-car").then(res => {
      setCars(res.data);
    });
  }, []);

  return (
    <>
      <h4 className="mb-3">Daftar Mobil</h4>

      <div className="row g-3">
        {cars.map(car => (
          <div key={car.id} className="col-md-4">
            <div className="card h-100">
              <div className="card-body">
                <h6>{car.brand} {car.model}</h6>
                <p>Harga: Rp {car.price.toLocaleString()}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
