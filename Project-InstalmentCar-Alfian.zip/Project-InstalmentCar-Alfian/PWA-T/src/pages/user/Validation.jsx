import { useState } from "react";
import api from "../../services/api";

export default function Validation() {
  const [form, setForm] = useState({ job: "", income: "" });

  const submit = async (e) => {
    e.preventDefault();
    await api.post("/validation", form);
    alert("Validasi dikirim");
  };

  return (
    <>
      <h4>Validasi Data</h4>

      <form onSubmit={submit} className="card p-3 mt-3" style={{ maxWidth: 400 }}>
        <input
          className="form-control mb-2"
          placeholder="Pekerjaan"
          onChange={(e) => setForm({ ...form, job: e.target.value })}
        />

        <input
          className="form-control mb-3"
          placeholder="Penghasilan"
          type="number"
          onChange={(e) => setForm({ ...form, income: e.target.value })}
        />

        <button className="btn btn-primary">Kirim</button>
      </form>
    </>
  );
}
