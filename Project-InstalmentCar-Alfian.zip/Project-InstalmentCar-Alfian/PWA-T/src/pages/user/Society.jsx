import { useEffect, useState } from "react";
import api from "../../services/api";

export default function Society() {
  const [data, setData] = useState({});

  useEffect(() => {
    api.get("/society/me").then(res => setData(res.data));
  }, []);

  return (
    <>
      <h4>Profil Saya</h4>

      <div className="card p-3 mt-3" style={{ maxWidth: 400 }}>
        <p><b>Nama:</b> {data.name}</p>
        <p><b>NIK:</b> {data.id_card_number}</p>
        <p><b>Alamat:</b> {data.address}</p>
        <p><b>Telp:</b> {data.phone}</p>
      </div>
    </>
  );
}
