import { useEffect, useState } from "react";

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    users: 0,
    applications: 0,
    validations: 0,
  });

  const [date] = useState(new Date().toLocaleDateString());

  useEffect(() => {
    const saved = localStorage.getItem("admin_stats");

    if (saved) {
      setStats(JSON.parse(saved));
    } else {
      const dummy = {
        users: 128,
        applications: 42,
        validations: 9,
      };
      localStorage.setItem("admin_stats", JSON.stringify(dummy));
      setStats(dummy);
    }
  }, []);

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Tanggal: {date}</p>

      <div style={{ display: "flex", gap: 16, marginTop: 20 }}>
        <Card title="Total Users" value={stats.users} />
        <Card title="Applications" value={stats.applications} />
        <Card title="Pending Validation" value={stats.validations} />
      </div>
    </div>
  );
}

function Card({ title, value }) {
  return (
    <div style={{
      border: "1px solid #ccc",
      padding: 16,
      borderRadius: 8,
      minWidth: 150
    }}>
      <h4>{title}</h4>
      <strong>{value}</strong>
    </div>
  );
}
