import { useEffect, useState } from "react";
import api from "../../services/api";

export default function Society() {
  const [society, setSociety] = useState([]);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const res = await api.get("/society");
    setSociety(res.data);
  };

  const del = async (id) => {
    if (!confirm("Delete society?")) return;
    await api.delete(`/society/${id}`);
    load();
  };

  return (
    <>
      <h4>Society</h4>
      <table className="table">
        <thead>
          <tr><th>Name</th><th>Address</th><th>Phone</th><th>Action</th></tr>
        </thead>
        <tbody>
          {society.map(s => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.address}</td>
              <td>{s.phone}</td>
              <td>
                <button className="btn btn-danger btn-sm" onClick={() => del(s.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
