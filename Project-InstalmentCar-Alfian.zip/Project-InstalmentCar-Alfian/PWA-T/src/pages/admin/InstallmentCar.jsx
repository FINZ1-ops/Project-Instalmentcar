import { useEffect, useState } from "react";
import api from "../../services/api";

export default function InstallmentCar() {
  const [cars, setCars] = useState([]);
  const [form, setForm] = useState({
    brand: "",
    model: "",
    price: ""
  });

  const role = localStorage.getItem("role");

  useEffect(() => {
    if (role === "admin") {
      load();
    }
  }, [role]);

  const load = async () => {
    try {
      const res = await api.get("/instalment-car");
      setCars(res.data);
    } catch (err) {
      console.error("Load instalment car failed", err);
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post("/instalment-car", form);
      setForm({ brand: "", model: "", price: "" });
      load();
    } catch (err) {
      console.error("Create car failed", err);
    }
  };

  const del = async (id) => {
    if (!window.confirm("Delete this car?")) return;
    await api.delete(`/instalment-car/${id}`);
    load();
  };

  return (
    <>
      <h4>Instalment Car</h4>

      <form className="row g-2 mb-4" onSubmit={submit}>
        <input
          className="form-control col"
          placeholder="Brand"
          value={form.brand}
          onChange={e => setForm({ ...form, brand: e.target.value })}
        />
        <input
          className="form-control col"
          placeholder="Model"
          value={form.model}
          onChange={e => setForm({ ...form, model: e.target.value })}
        />
        <input
          className="form-control col"
          placeholder="Price"
          type="number"
          value={form.price}
          onChange={e => setForm({ ...form, price: e.target.value })}
        />
        <button className="btn btn-primary col">Add</button>
      </form>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Brand</th>
            <th>Model</th>
            <th>Price</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {cars.map(c => (
            <tr key={c.id}>
              <td>{c.brand}</td>
              <td>{c.model}</td>
              <td>{c.price}</td>
              <td>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => del(c.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
