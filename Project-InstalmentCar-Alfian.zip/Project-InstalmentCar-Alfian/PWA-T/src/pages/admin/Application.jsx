import { useEffect, useState } from "react";
import api from "../../services/api";

export default function Validation() {
  const [data, setData] = useState([]);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const res = await api.get("/validation");
    setData(res.data);
  };

  const approve = async (id) => {
    await api.put(`/validation/${id}/approve`);
    load();
  };

  const reject = async (id) => {
    const reason = prompt("Reason?");
    await api.put(`/validation/${id}/reject`, { reason });
    load();
  };

  return (
    <>
      <h4>Validation</h4>
      <table className="table">
        <thead>
          <tr><th>Society</th><th>Job</th><th>Income</th><th>Action</th></tr>
        </thead>
        <tbody>
          {data.map(v => (
            <tr key={v.id}>
              <td>{v.society_id}</td>
              <td>{v.job}</td>
              <td>{v.income}</td>
              <td>
                <button className="btn btn-success btn-sm me-2" onClick={() => approve(v.id)}>Approve</button>
                <button className="btn btn-danger btn-sm" onClick={() => reject(v.id)}>Reject</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
