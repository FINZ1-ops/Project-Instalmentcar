import {Navigate,Outlet} from "react-router-dom";

export default function AdminRoute() {
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");

    if (!token || !role){
        return <Navigate to="/login" replace/>;
    }

    if (role !=="admin"){
        return <Navigate to="/user/dashboard" replace/>
    }   

    return <Outlet/>;
}
